package exceptions;

public class ModelNotFoundException extends RuntimeException{
}
