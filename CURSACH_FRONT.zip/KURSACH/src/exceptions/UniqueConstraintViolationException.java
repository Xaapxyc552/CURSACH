package exceptions;

public class UniqueConstraintViolationException extends RuntimeException {
}
