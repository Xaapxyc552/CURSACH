package dao;

import model.test.Test;
import model.test.Topic;

public interface TopicDao extends Dao<Topic>{

}
