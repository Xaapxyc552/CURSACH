package dao.impl;

public enum ModifyingOperation {
    DELETE,UPDATE
}
