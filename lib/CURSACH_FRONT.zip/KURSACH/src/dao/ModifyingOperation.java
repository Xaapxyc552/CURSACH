package dao;

public enum ModifyingOperation {
    DELETE,UPDATE
}
