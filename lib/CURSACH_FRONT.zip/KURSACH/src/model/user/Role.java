package model.user;

public enum Role {
    STUDENT,TEACHER,ADMIN
}
