package model;

import java.util.UUID;

public interface Model {
    UUID getId();
}
