package service.impl;

import model.result.Statistics;
import model.result.TestResult;
import model.user.User;
import service.AnswerCheckerService;

public class AnswerCheckerServiceImpl implements AnswerCheckerService {
    @Override
    public Statistics getStatFromTestResult(TestResult testResult, User user) {
        return null;
    }
}
