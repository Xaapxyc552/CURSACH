package service;

public interface Service {
}
